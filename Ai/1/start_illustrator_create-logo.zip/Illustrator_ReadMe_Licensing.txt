READ ME
Licensing of Sample Files for Adobe Illustrator

Table of contents
1. Use of Sample Files.


Use of Sample Files.
You can use the sample files accompanying our Getting Started tutorials 
in the ways outlined in Section 6(a) of the Adobe Terms of Use. 

In addition, you are permitted to:   
   * Modify the sample files.   
   * Copy and distribute the sample files if you agree: 	
     * Not to lease, license, rent, or sell the sample files or otherwise 
       use the sample files for commercial purposes; and 
     * Not to remove, obscure, or alter any licensing text such as 
       watermarks or proprietary notices contained in the sample files.

 The sample files are provided by Adobe "AS IS" without warranty of any kind.


